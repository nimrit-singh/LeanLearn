export interface CommonQty{
    id:string;
    qty_name:string;
    qty_symbol:string;
}