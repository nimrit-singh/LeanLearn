import { MCQQuestion,FillQuestion,TFQuestion,FormulaQuestion } from "./quizInterface";

export type QuestionType = MCQQuestion | FillQuestion | TFQuestion | FormulaQuestion;
