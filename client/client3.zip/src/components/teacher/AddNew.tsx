import React from 'react'

const AddNew = () => {
  return (
    <div>AddNew</div>
  )
}

export default AddNew