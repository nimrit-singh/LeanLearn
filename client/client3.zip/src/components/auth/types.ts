interface User {
    photoURL: string | null;
    displayName: string;
  }
  
  export default User;